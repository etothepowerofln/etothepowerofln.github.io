/*
 * Keyboard routines
 * Copyright (C) 2014 Mateusz Viste
 * All rights reserved.
 */

#ifndef keyb_h_sentinel
  #define keyb_h_sentinel

  /* wait for a keypress and return it. Returns 0 for extended keystroke,
   * then function must be called again to return scan code. */
  int keyb_getkey(void);

  /* poll the keyboard, and return the next input key if any, or -1 */
  int keyb_getkey_ifany(void);

  /* flush the keyboard buffer */
  void keyb_flush(void);

#endif
