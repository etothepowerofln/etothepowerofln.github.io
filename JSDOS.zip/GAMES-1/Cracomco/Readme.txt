CRAZY COMPUTER COMPETITION
==========================

Table of Contents:
> System Requirements
> Plot
> Controls
> Development
> Soundtrack

> System Requirements:
Windows 98 is perfect. Windows 95 is fine. Windows 3.11 should use its DOS mode instead. Because pure DOS works, that was tested! 
100 Mhz in that 1995 laptop is more than enough. DOS needs about 574k of free memory (check that with the "mem"-command).
Files: Cracomco.rpg, Cracomco.exe, ohrrpgce.fnt, ohrrpgce.mas (about 1 MB)
The computer needs to be able to play MIDI or Adlib properly, because the fantastic orchestra music has to announce every win bright and rich in sound. Fingers off this game, if your computer stays silent on the startup. It will lack its true atmosphere.
How to run the game on new computers: First option, use DOSbox with the Adlib sound being emulated. Or as a second option, download the current version of the OHRRPGCE from this site: http://rpg.hamsterrepublic.com/ohrrpgce/Downloads
And run the RPG file through running game.exe.

> Plot:
Your girlfriend asks you to become rich. You heard, that computer freaks become quite rich. So you participate in a computer challenge, where competitors use their machines in battles to show, who the best is. Travel through the history of computing, from mainframes to flatscreens! And explore the question, if newer is always better.

> Controls:
Arrows keys to move, Enter and Escape to use the menus. Very simple.
The battles however can't be taken relaxed. Quick actions are needed, or the enemy is ready before you even blink!
A team can consist out of three computers. They can be reordered at specific places, like shops. To buy additional computers, there must be a free place in the group, so some old stuff has to be put into the reserve. That can be done at shops.

> Development:
CraComCo was created with the OHRRPGCE, a free and open game engine, that lasts since more than 20 years now. The initial development of this game took place for the 2020 Ridiculous Games Contest, which had the theme to create a game that could have been developed in the young days of the OHR. To do so, only features that were present in the 1998 version of the OHRRPGCE were available to the developers. Only 4 maps and no plotscripts were used. So to make such an RPG as CraComCo with the OHRRPGCE, no programming skills would have been required, just some creativity and lots of time. About 20 days were used for the making of this game, quite something for a finished game that is one hour long, including efficently scratched graphics. In 2021, I was testing on two more days to improve the gameplay balance to prepare the game for an upload to Doshaven. I'd like to know, how the OHRRPGCE performs on older computers than my Pentium 3. Would you write me an e-mail about the stats of your computer? And also about the bugs that you've encountered!
To edit the game files, get the 2006 hasta-la-qb+ version of the OHRRPGCE. That was the last version to include the QuickBasic builds (http://hamsterrepublic.com/ohrrpgce/archive/).
Much better pixel graphics had been made by Feenicks with his game "Union Tour", which also used the DOS version of the OHRRPGCE (https://www.slimesalad.com/forum/viewtopic.php?p=136712). Those show, what can be done with the 256 colours of the OHRRPGCE.

> Soundtrack:
These are special musical tracks by Marius Beckmann, who currently is an organist in Augsburg (Germany), but even more so a film soundtrack composer of the old school deep down at heart. He made a couple of compositions, of which some were made with Sibelius, so exportable as MIDI, so perfectly useable by the old OHRRPGCE. Actually, there were times before MIDI was properly supported, so that the less capable BAM music format had to be used for a proper 1998 OHR experience. The big problem with computer generated music (like BAM and MIDI), as opposed to actual recorded wave-forms (like WAV and MP3) is, that it highly depends on the soundcard in use. Whatever device that might be!

Bird (E-Mail: windows98@posteo.de)
- November of 2021